import { Router } from 'express'
import bcrypt from 'bcrypt'
import db from './database.js'

const router = Router()

router.post('/register', async (req, res) => {
  try {
    const {
      firstname,
      lastname,
      email,
      phone,
      password,
      gender
    } = req.body

    if (!firstname || !lastname || !email || !phone || !password || !gender) {
      return res.status(400).json({
        error: 'Preencha todos os campos'
      })
    }

    // criptografar senha
    const passwordHash = await bcrypt.hash(password, 10)

    //salvamento no banco
   await db.run(
  `INSERT INTO users (firstname, lastname, email, phone, gender, password)
   VALUES (?, ?, ?, ?, ?, ?)`,
  [firstname, lastname, email, phone, gender, passwordHash]
)


    return res.status(201).json({
      message: 'Usuário cadastrado com sucesso 🎉'
    })

  } catch (error) {
    console.error(error)
    return res.status(500).json({
      error: 'Erro interno do servidor'
    })
  }
})

export default router