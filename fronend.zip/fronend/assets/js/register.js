document.getElementById('registerForm').addEventListener('submit', async (e) => {
  e.preventDefault()

  const firstname = document.getElementById('firstname').value
  const lastname = document.getElementById('lastname').value
  const email = document.getElementById('email').value
  const phone = document.getElementById('phone').value
  const password = document.getElementById('password').value
  const confirmPassword = document.getElementById('confirmPassword').value

  const genderInput = document.querySelector('input[name="gender"]:checked')

  if (!genderInput) {
    alert('Selecione um gênero')
    return
  }

  if (password !== confirmPassword) {
    alert('As senhas não coincidem')
    return
  }

  const data = {
    firstname,
    lastname,
    email,
    phone,
    password,
    gender: genderInput.value
  }

  try {
    const response = await fetch('http://localhost:3000/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    })

    const result = await response.json()

    if (!response.ok) {
      alert(result.error || 'Erro ao cadastrar')
      return
    }

    alert(result.message)
    document.getElementById('registerForm').reset()

  } catch (error) {
    alert('Erro ao conectar com o servidor')
    console.error(error)
  }
})